$(function() {
     $('.bs-docs-sidenav').affix({
        offset: {
          top: 210
        , bottom: 270
        }
      });
});